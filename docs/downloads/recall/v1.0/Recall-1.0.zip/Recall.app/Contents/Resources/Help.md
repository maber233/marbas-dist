# Recall — Quick Reference

## What is Recall?

Recall is a macOS menu bar app that **records meetings**, **transcribes audio**, and generates **AI-powered summaries** — all locally from your Mac.

---

## Getting Started

1. **Add an AI provider** — Open **Settings → AI Providers** and enter an API key for at least one provider (OpenAI, Anthropic, Google Gemini, or GitHub Copilot). Or use **Local (Ollama)** for fully offline operation — no API key needed.
2. **Choose a transcription provider** — Under **Settings → Recording**, pick Cloud (OpenAI Whisper) or Local (WhisperKit).
3. **Start recording** — Click the Recall menu bar icon and press **Start Recording**.

---

## Recording

- **System audio** captures everything your Mac plays (meeting apps, browser, etc.) via ScreenCaptureKit. System audio is automatically reduced in volume and a soft limiter prevents distortion when mixed with the microphone. Recall also normalizes capture streams to a fixed internal format and uses a short audio buffer to smooth timing jitter, which improves compatibility and playback quality with external soundcards.
- **Microphone** captures your voice via the selected input device. Recall now handles multi-channel/multi-buffer input layouts used by some external soundcards more reliably.
- **Microphone selection** — Choose your preferred microphone in **Settings → Recording → Microphone**, or switch devices live during a recording using the device menu next to the audio toggles. A **Test Microphone** button in Settings lets you verify the device works before a meeting. If the selected device is disconnected, the system default is used automatically.
- **Mute toggles** — Use the mic/system switches during recording to mute either source without stopping the session. Useful during coffee breaks or off-topic moments. The toggles and mic picker share a single compact row.
- **Session name** — Optionally give your session a name (e.g., "Sprint Planning") so it's easy to find in the history. If left blank, sessions are identified by date/time. You can also edit the name later in the session detail view.
- **Meeting context** — Type notes (e.g., attendees, agenda) that help the AI produce better summaries.
- **Infographic & summary level** — Toggle infographic generation and choose the summary level (brief / standard / detailed) from a single row below the context field.
- **Pause / Resume** — Tap the pause button to freeze recording. Time spent paused is excluded from the session duration.
- **Cancel** — Discard the current recording entirely (with confirmation).
- **Stop & Process** — End recording and begin the transcription → summary pipeline.
- **Lid close / sleep** — If you close your laptop lid (or the system sleeps) during a recording, Recall automatically stops the recording and processes it. When you reopen the lid, you'll see your results ready.
- **Abort Processing** — While the pipeline is running (transcribe, summarize, infographic), press the **Abort** button to cancel. If a summary has already been generated, you'll go straight to the results view and can still copy it. If not, you'll return to the start screen.

---

## Session History

Click **History** in the menu bar footer to open the Session History window. It shows all past sessions with their date, duration, and status icons (audio, transcript, summary, infographic).

- **View session details** — Click a session to see its summary, infographic, and transcript with copy buttons for each.
- **Re-summarize** — Edit the meeting context, toggle infographic generation, choose a summary level, and click **Re-summarize** to regenerate the summary with your current AI provider settings. The new results replace the original in place.
- **No auto-export on redo** — Re-processed summaries and infographics are **not** automatically exported to Obsidian or markdown files, even if enabled in preferences. This is because a redo may happen at a different time. Copy results manually using the copy buttons.
- **Delete session** — Right-click a session in the list or use the delete button in the detail view to permanently remove all associated files.
- **Delete all sessions** — Click the **Delete All** button in the toolbar to permanently remove all sessions and their associated files. A confirmation dialog will ask you to confirm before anything is deleted.

---

## Meeting Detection

Recall can automatically detect when a video-conferencing meeting starts and prompt you to record.

- **Enable** in **Settings → Misc → Auto-detect meetings**.
- When a supported app (Teams, Zoom, Webex, Slack) starts a call, you'll see a notification: **"Recall this meeting?"**
- Tap **Recall** to start recording immediately, or **Skip** to dismiss.
- Recall never records automatically — you always choose per meeting.
- After skipping, there's a 5-minute cooldown before prompting again for the same app.

---

## Transcription

| Option | Description |
|--------|-------------|
| **Cloud (OpenAI Whisper)** | Fast, accurate. Requires an OpenAI API key and internet. |
| **Local (WhisperKit)** | Runs entirely on-device. No data leaves your Mac. Downloads a model on first use. Models are stored in `~/Library/Application Support/Recall/WhisperKit/`. |

Select a **language** to improve accuracy, or leave it on auto-detect.

### Live Transcription

Enable **Live Transcription** in **Settings → Recording → Transcription Mode** to get a real-time transcript while recording.

- Audio is transcribed in ~30-second chunks during the meeting in the background.
- When you stop recording, the transcript is immediately available — no waiting for batch transcription.
- Works with both Cloud and Local transcription providers.
- **Trade-off:** Shorter audio chunks may produce slightly less accurate results than batch transcription of the full recording. If accuracy is your priority, leave live transcription off.
- The audio file is always saved regardless, so you can re-process it later if needed via **Load Audio**.

When live transcription is **off** (the default), the full audio is transcribed after recording stops — this gives the best accuracy.

---

## Summarization

- **Smart title** — The summary title reflects the actual meeting name (from context) or is inferred from the transcript content. No generic "Meeting Summary" headers.
- **Meeting time & duration** — The summary always shows when the meeting started and how long it lasted. This reflects the original meeting time, even if the summary is regenerated days later.
- **Summary levels**: *Compact* (bullet points), *Normal* (structured sections), or *Detailed* (comprehensive narrative).
- **Dynamic scaling** — Word count targets automatically scale with meeting length. A 10-minute sync gets a concise summary; a 2-hour workshop gets a thorough one. No configuration needed.
- **Key Decisions / Takeaways** — Important conclusions and decisions are listed in a dedicated section.
- **Action items** — Only included when genuine, specific action items exist (tasks with owners or deadlines). The section is omitted entirely if none are found.
- **Custom prompts** — Add extra instructions for the AI, e.g. "Focus on action items" or "Write in Swedish".
- **Provider selection** — Pick which AI provider generates the summary in **Settings → Output**.

---

## Infographics

When enabled, Recall generates a visual infographic of your meeting using AI image generation.

- Requires a provider that supports image generation (e.g. OpenAI with DALL·E).
- Toggle it on per-session from the recording view, or set the default in **Settings → Output**.

---

## Settings

The Settings window uses a sidebar for navigation. Select a section on the left to view its options:

| Section | What it controls |
|---------|------------------|
| **AI Providers** | Configure AI providers, organized into **Online Providers** (OpenAI, Anthropic, GitHub Copilot, Gemini) and **Local Providers** (WhisperKit, Ollama, ComfyUI, Core ML Stable Diffusion). |
| **Transcription** | Transcription provider and language. |
| **Summary** | Summary provider & model, summary level, notifications, custom summary prompt template. |
| **Infographic** | Infographic LLM & image generation providers, default toggle, custom infographic prompt template. |
| **Export** | External export to Obsidian or other note-taking apps (summary file, infographic image, link format). |
| **Misc** | Max recording duration, audio quality, storage location, auto-delete. |

---

## External Export (Obsidian Integration)

Optionally export summaries and infographics to external folders — ideal for integrating with Obsidian, Logseq, or any Markdown-based notes system.

Configure in **Settings → Export**:

- **Summary export** — Toggle on, choose a target folder, and set a filename template. The summary is appended to the file (creating it if new). Useful for appending meeting notes to Obsidian daily notes.
- **Infographic export** — Toggle on and choose a folder. The PNG is copied there automatically.
- **Link format** — Choose how the infographic is referenced in the summary:
  - *Obsidian wiki-link*: `![[recall-20260416-143052.png]]`
  - *Markdown relative*: `![Infographic](recall-20260416-143052.png)`
  - *None*: no image link

### Filename template variables

| Template | Example result |
|----------|---------------|
| `{{DATE}}` | `2026-04-16.md` |
| `{{DATE:YYYY-MM-DD}}` | `2026-04-16.md` |
| `{{DATE:YYYYMMDD}}` | `20260416.md` |
| `{{DATE:YYYY-MM-DD_HH-mm}}` | `2026-04-16_14-30.md` |
| `{{TIME:HH-mm}}` | `14-30.md` |

The `.md` extension is added automatically. A live preview is shown in settings.

> **Note:** Files in the default Recall storage location are always created regardless of export settings. Export failures are logged but never block the pipeline.

---

## Max Recording Duration

- Set a **default max duration** in **Settings → Recording** (default: 1 hour). Set to 0h 0m for unlimited.
- **Adjust per-session** before recording from the setup screen.
- A **countdown** appears during recording showing remaining time.
- At **1 minute remaining**, a system notification warns you. Tap **Extend** on the notification or in the recording view to add more time.
- If time runs out without extending, the recording **auto-stops** and proceeds through the normal pipeline.
- You can extend multiple times — each adds the configured extension duration (default: 15 minutes).

---

## Storage

- By default, files are stored in `~/Library/Application Support/Recall/`.
- Change the location in **Settings → Recording → Storage → Choose Folder…**.
- Existing files are not moved — only new sessions use the updated location.
- Use **Reset to Default** to switch back to the original location.

---

## Diagnostic Logs

Recall writes a daily log file for troubleshooting during the beta period:

- **Location:** `~/Library/Application Support/Recall/Logs/recall_YYYY-MM-DD.log`
- **Content:** App lifecycle events, session phase transitions, pipeline timing, errors. No personal data (transcripts, summaries, context, or API keys) is logged.
- **Rotation:** Logs older than 7 days are automatically deleted.
- If you encounter an issue, locate the log file in Finder and share it with the development team.

---

## Tips

- **Load an existing file** — Drop an audio file or plain-text transcript onto the setup screen to summarize content you already have.
- **Clipboard output** — Summaries are automatically copied to the clipboard for quick pasting into notes or docs.
- **Mute your mic** during breaks to keep the transcript clean, without stopping the recording.
- **Extend recording** — If a meeting runs long, tap +15 min instead of stopping and starting a new session.
- **Local transcription** keeps everything on-device — great for sensitive meetings.

---

## Local AI with Ollama

Recall supports running AI summarization, infographic prompt generation, and image generation entirely on your Mac using **Ollama**, a local model runner. No API keys, no internet, no data leaves your machine.

### Setup

1. **Install Ollama** — Download from [ollama.com](https://ollama.com) or run:
   ```
   brew install ollama
   ```
2. **Start the Ollama server:**
   ```
   ollama serve
   ```
   Or just open the Ollama app — it starts the server automatically.
3. **Pull a model** (e.g. Llama 3.2):
   ```
   ollama pull llama3.2
   ```
4. **Configure in Recall** — Go to **Settings → AI Providers**, select the **Local (Ollama)** section, click **Test Connection**, then **Refresh Models**.
5. **Select Ollama** as your summarization provider in the **Task Routing** section at the top.

### Image generation with Ollama

Ollama can also generate infographic images using multimodal models that support image output:

1. Pull a model that supports image generation:
   ```
   ollama pull gemma4
   ```
2. Select **Ollama** as your infographic image provider in the **Task Routing** section.
3. Choose the image-capable model (e.g. `gemma4`) from the model picker.

If the selected model doesn't support image generation, Recall will show a clear error message suggesting you switch to a compatible model.

### Recommended models

| Model | Size | Best for |
|-------|------|----------|
| `llama3.2` | ~2 GB | Good balance of speed and quality |
| `mistral` | ~4 GB | Fast, good for shorter meetings |
| `llama3.1` | ~4.7 GB | Higher quality summaries |
| `gemma4` | ~5 GB | Summarization + image generation |

### Notes

- Local models are slower than cloud APIs — long transcripts may take 30–60 seconds.
- Smaller models may produce lower quality summaries than GPT-4o or Claude.
- Ollama must be running before you start processing. If it's not running, Recall will show a clear error message.
- The server URL defaults to `http://localhost:11434`. Change it in settings if needed.

---

## Choosing a Local Image Generation Option

Recall offers two ways to generate infographic images locally. Here's how they compare:

| | Native Stable Diffusion | ComfyUI (Advanced) |
|---|---|---|
| **Ease of setup** | One-click download in Recall settings | Requires installing and configuring a separate app |
| **External software** | None — runs inside Recall | ComfyUI must be installed and running |
| **Best model** | SDXL Compressed (1024×1024) | Any model ComfyUI supports (SDXL, FLUX, fine-tunes, etc.) |
| **Customization** | Fixed pipeline | Full control over workflows, samplers, LoRAs, ControlNet, etc. |
| **Recommended for** | Most users | Power users who already know ComfyUI |

**Our recommendation:** Start with **Native Stable Diffusion** (SDXL Compressed). It's the easiest to set up and produces good results. Only consider ComfyUI if you already use it or need advanced customization.

---

## Local Image Generation with ComfyUI (Advanced)

> **⚠️ Advanced option** — ComfyUI setup requires familiarity with Stable Diffusion tooling, model management, and running local servers. If you're not already comfortable with these concepts, use **Native Stable Diffusion** instead (see next section) — it's much simpler.

Recall supports generating infographic images locally using **ComfyUI**, an open-source Stable Diffusion interface. No API keys, no internet, no data leaves your machine. ComfyUI gives you the most flexibility — you can use any model, sampler, LoRA, or workflow configuration — but it requires more setup and understanding.

### Prerequisites

- Familiarity with Stable Diffusion concepts (checkpoints, samplers, steps, CFG scale)
- Comfort with installing and managing local applications
- At least 8 GB of RAM (16 GB+ recommended for SDXL models)

### Setup

1. **Install ComfyUI** — Download and install from [comfy.org/download](https://www.comfy.org/download). This gives you the ComfyUI Desktop app which includes everything you need.

2. **Launch ComfyUI** — Open the app. It will start a local server and show the node-based UI in your browser. Check the log/terminal output for the server URL — it's usually `http://127.0.0.1:8000`, but **your port may differ**. Make a note of the exact URL.

3. **Download a checkpoint model** — ComfyUI needs a Stable Diffusion model ("checkpoint") to generate images. The easiest way:

   1. In ComfyUI, click the **folder icon** (Workflows) in the left sidebar
   2. Click **"Browse example workflows"** at the top
   3. Select the **"Image Generation"** workflow
   4. ComfyUI will show a **"Missing Models"** prompt — click **Download**
   5. Wait for the download to finish (~4 GB for the default model)

   This automatically downloads `v1-5-pruned-emaonly-fp16.safetensors` into the correct folder.

   **Alternative:** Download a model manually from [CivitAI](https://civitai.com) or [Hugging Face](https://huggingface.co) and place the `.safetensors` file in ComfyUI's `models/checkpoints/` folder. For better quality, look for SDXL-based models.

4. **Verify the server is reachable** — Open this URL in your browser (adjust port if needed):
   ```
   http://127.0.0.1:8000/system_stats
   ```
   If you see JSON output, the server is running and Recall can connect to it. If not, check the ComfyUI app/terminal for the correct URL.

5. **Configure in Recall** — Go to **Settings → AI Providers**, scroll to the **Local (ComfyUI)** section:
   - Set the **Server URL** — this **must match exactly** the URL from step 2 (including port number)
   - Click **Refresh** to load available checkpoints from ComfyUI
   - Click **Test Connection** to verify Recall can reach ComfyUI

6. **Select ComfyUI** as your image generation provider in **Settings → Infographic → Image Generation**, and choose a checkpoint from the dropdown.

### Custom Workflows (Advanced)

The built-in workflow uses `CheckpointLoaderSimple`, which only works with single-file checkpoints. If you want to use models that need different loaders (FLUX, GLM, etc.), you can provide your own workflow:

1. **Design your workflow** in ComfyUI's browser UI with whatever nodes and model loaders you need
2. **Export in API format** — In ComfyUI, click the menu and select **Save (API Format)** to download the workflow JSON
3. **Select the file** in Recall — In **Settings → AI Providers → ComfyUI**, click **Choose…** next to "Workflow" and select your exported JSON file
4. Recall will inject the infographic prompt into the first `CLIPTextEncode` node in your workflow

To go back to the built-in workflow, click **Clear**.

### Troubleshooting

| Problem | Solution |
|---------|----------|
| Test Connection fails | Open `http://127.0.0.1:8000/system_stats` in a browser. If it doesn't load, ComfyUI isn't running or uses a different port. Check the ComfyUI log/terminal output for the actual URL and port. |
| No checkpoints after Refresh | Make sure your model files are in ComfyUI's `models/checkpoints/` folder and ComfyUI has been restarted after adding them. |
| Model not in checkpoint list | Models using different loaders (FLUX, GLM, etc.) won't appear in the checkpoint list. Use a **custom workflow** instead (see above). |
| Image generation fails | Make sure ComfyUI can generate an image on its own first (try running a workflow in the ComfyUI browser UI). |
| Slow generation | Normal for local generation. Apple Silicon GPUs help significantly. Expect 30–120 seconds per image depending on your Mac and the model size. |
| ComfyUI uses wrong port | The default port varies by installation. Check the ComfyUI startup log for the actual URL. Common ports are `8000`, `8188`, and `8189`. |

### How it works

Recall sends a text-to-image workflow to ComfyUI via its REST API. When using the built-in workflow, it uses KSampler with 20 steps, euler sampler, and your selected checkpoint. When using a custom workflow, Recall loads your JSON file and injects the LLM-generated infographic prompt into the first CLIPTextEncode node, then submits it to ComfyUI.

### Notes

- Image generation is **slower locally** than cloud APIs — expect 30–120 seconds depending on your hardware and model.
- A GPU (Apple Silicon or NVIDIA) significantly speeds up generation. CPU-only is possible but very slow.
- **ComfyUI must be running** before you start processing in Recall. If it's not running, Recall will show a connection error. Consider launching ComfyUI before your meetings.
- The generated image resolution depends on your workflow configuration.
- You can use any Stable Diffusion checkpoint — just update the checkpoint name in settings to match. SDXL checkpoints generally produce better results than SD 1.5.
- For best results, experiment with different checkpoints in ComfyUI's own UI first to find one that produces images you like, then configure that checkpoint in Recall.

---

## Native Image Generation (Recommended)

Recall can generate infographic images **entirely on-device** using Apple's Core ML Stable Diffusion — no server to install, no API keys, no internet required. This is the **simplest and recommended way** to generate images locally.

### How it works

Recall uses Apple's [ml-stable-diffusion](https://github.com/apple/ml-stable-diffusion) Swift package to run Stable Diffusion models directly on your Mac via Core ML. The models use the Apple Neural Engine and GPU for acceleration.

### Setup

1. **Open Settings → AI Providers** and scroll to the **Local (Stable Diffusion)** section.

2. **Select a model** — Choose from the available variants:
   - **Stable Diffusion 1.5 (Compressed)** — ~1 GB download, 512×512 images. Good quality, fastest.
   - **Stable Diffusion 2.1 (Compressed)** — ~1.5 GB download, 768×768 images. Better quality, slightly slower.
   - **Stable Diffusion XL (Full)** — ~5 GB download, 1024×1024 images. Significantly better quality and detail.
   - **Stable Diffusion XL (Compressed)** — ~2.5 GB download, 1024×1024 images. Best quality/size trade-off. **Recommended.**

3. **Click "Download Model"** — The model will be downloaded from Hugging Face. Progress is shown in the settings view. This is a one-time download.

4. **Select Local (Stable Diffusion)** as your image generation provider in **Settings → Infographic → Image Generation**.

That's it! No server to run, no terminal commands, no external apps.

### Available Models

| Model | Size | Resolution | Notes |
|-------|------|------------|-------|
| SD 1.5 Compressed | ~1 GB | 512×512 | Best for speed. Good quality. |
| SD 2.1 Compressed | ~1.5 GB | 768×768 | Better detail. Slightly slower. |
| SDXL Full | ~5 GB | 1024×1024 | Significantly better quality. Uses dual text encoders. |
| SDXL Compressed | ~2.5 GB | 1024×1024 | **Recommended.** Best quality/size trade-off. |

### Troubleshooting

| Problem | Solution |
|---------|----------|
| Download fails | Check your internet connection. The models are downloaded from Hugging Face (huggingface.co). |
| Generation is slow | Normal — expect 10-30 seconds on Apple Silicon. Older or lower-end Macs will be slower. |
| Out of memory | Close other memory-intensive apps. The pipeline uses `reduceMemory` mode to minimize footprint. |
| Image quality is low | Local models produce lower quality than cloud APIs (DALL-E, Gemini). This is expected. Try SDXL Compressed for the best local quality. |

### Notes

- **Apple Silicon required** — Core ML Stable Diffusion runs on M1/M2/M3/M4 chips. Intel Macs are not supported.
- Generation takes ~10-30 seconds depending on your hardware.
- Models are stored in `~/Library/Application Support/com.recall.app/DiffusionModels/`. You can delete them from settings to free disk space.
- The pipeline uses the DPM-Solver++ scheduler with 20 inference steps (25 for SDXL) for a good speed/quality balance.
- SDXL models use dual text encoders for much better prompt adherence and image quality.
- Unlike ComfyUI, no external server needs to be running — the model runs within Recall itself.
- **SDXL Compressed is the recommended model** for most users — it offers the best balance of quality and download size.

---

## Distribution Artifacts (Maintainers)

For website distribution, use the release script in the project root:

```bash
./scripts/release.sh
```

Versioning behavior:

- Default release increments the minor version (`1.0 -> 1.1 -> 1.2`)
- Major release: `./scripts/release.sh --major` (`1.9 -> 2.0`)
- Explicit version: `./scripts/release.sh --version 3.4`
- If current version is beta (`1.0-beta.1`), next release stabilizes to `1.0`

It generates a clean `dist/` directory with:

- `Recall.app` (the app bundle)
- `Recall-<version>-build<build>.zip` (compressed app)
- `SHA256SUMS.txt` (SHA-256 checksums for verification)

Per-release note files are written to the repository (not dist) at `docs/releases/v<version>.md`.

Upload these files to the distribution website.
