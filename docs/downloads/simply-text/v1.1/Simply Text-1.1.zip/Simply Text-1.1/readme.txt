Simply Text — Installation
==========================

To install Simply Text - open a terminal, move to the folder where the
install.sh file is located (same as this readme.txt), and run it:
> ./install.sh

The script removes the macOS download quarantine from the app
and copies it to /Applications. You can then launch Simply Text
from Launchpad or Spotlight.
