Simply Text — Installation
==========================

Double-click install.command to install the app.

The script removes the macOS download quarantine from the app
and copies it to /Applications. You can then launch Simply Text
from Launchpad or Spotlight.
