#!/bin/zsh
set -euo pipefail

# ─────────────────────────────────────────────────────
# Simply Text — Installer
#
# Removes the macOS quarantine flag set on internet-
# downloaded files and copies the app to /Applications.
# ─────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="Simply Text"
APP_BUNDLE="$SCRIPT_DIR/${APP_NAME}.app"
DEST="/Applications/${APP_NAME}.app"

if [[ ! -d "$APP_BUNDLE" ]]; then
    echo "✗ ${APP_NAME}.app not found next to this script."
    echo "  Make sure install.sh is in the same folder as the app."
    exit 1
fi

echo "Installing ${APP_NAME}..."

# Remove quarantine attribute (set by browsers on download)
xattr -cr "$APP_BUNDLE"

# Copy to /Applications (replace if already present)
if [[ -d "$DEST" ]]; then
    echo "→ Replacing existing installation..."
    rm -rf "$DEST"
fi

cp -R "$APP_BUNDLE" "$DEST"

echo "✓ ${APP_NAME} installed to /Applications"
echo "  You can now open it from Launchpad or Spotlight."
